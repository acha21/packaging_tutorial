def add_one(number):
    return number + 1
